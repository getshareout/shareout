# REST API: Error Codes

Standard error codes and their meanings. Stuck after reading the error? See
[SKILL.md § If you get stuck](../SKILL.md#if-you-get-stuck).

## Envelope

Every JSON error has the same shape:

```json
{
  "success": false,
  "error": "Unauthorized: this API key has expired.",
  "code": "UNAUTHORIZED",
  "reason": "expired",
  "hint": "Get a key: have the user open $ORIGIN/home?view=connect …",
  "docs": "$ORIGIN/v1/skill/auth.md",
  "request_id": "8a1f2c3d4e5f6a7b"
}
```

| Field | Always? | Meaning |
|-------|---------|---------|
| `success` | yes | `false` |
| `error` | yes | Human-readable message (device login keeps the RFC 8628 value here — see [Auth errors](#auth-errors)) |
| `code` | yes | Stable machine code — branch on this, never on `error` text |
| `request_id` | yes | Correlation id, same as the `X-Request-Id` header. Quote it in any support ticket |
| `hint` | often | What to do next, in plain words |
| `docs` | sometimes | Doc page for this error |
| `param` | sometimes | The request field at fault |
| `reason` | sometimes | Finer cause under `code` (e.g. `UNAUTHORIZED` → `missing` / `invalid` / `revoked` / `expired`) |
| `support` | on 5xx | `{ "how": "POST /v1/support/tickets", "include": ["request_id"] }` — how to reach a human |

On a 5xx, or when the same error repeats after following its `hint`, file a ticket
([support.md](support.md)) with what the user wanted, what you tried, the `code`, the
`request_id` and any `artifact_id`, then tell the user the team was notified.

## General Errors

| Code | Status | Description |
|------|--------|-------------|
| `UNAUTHORIZED` | 401 | No usable API key. `reason`: `missing` (no `Authorization: Bearer`), `invalid` (unknown key), `revoked`, or `expired`. `hint` says how to get a new one: the user opens `$ORIGIN/home?view=connect`, or run device login — [auth.md](../auth.md) |
| `FORBIDDEN` | 403 | Access denied — the key works but this person can't touch that workspace/page. Retrying won't help; a workspace admin has to invite them |
| `INSUFFICIENT_SCOPE` | 403 | A workspace Agent token (`sot_`) lacks the scope for this call (e.g. `artifacts:publish`) |
| `NOT_FOUND` | 404 | Resource not found |
| `ROUTE_NOT_FOUND` | 404 | No such `/v1` endpoint for that method and path (typo, wrong method, or trailing slash) — check the path in the docs |
| `INVALID_REQUEST` | 400 | Bad request format |
| `CONFLICT` | 409 | Version conflict |
| `RATE_LIMIT_EXCEEDED` | 429 | Rate limit on publish, account creation, and in-artifact AI (visitor chat / pilot). Body has `reset` / `retryAfter`; header `Retry-After` |
| `RATE_LIMITED` | 429 | Rate limit on the data plane (`/v1/data/…`), the CORS proxy, live connections, and share invites |
| `FEATURE_DISABLED` | 403 | Module not enabled for this workspace — see [features.md](features.md) |
| `INTERNAL_ERROR` | 500 | Unexpected server failure — body carries `request_id`, a `hint` and `support`. Retry once, then file a support ticket. On visitor chat / pilot / admin-chat routes, also returned (with `message: "AI provider not configured (set VERCEL_AI_GATEWAY, ANTHROPIC_API_KEY or OPENAI_API_KEY)"`) when the instance has no platform AI key and the workspace has no BYO key — see [error-recovery below](#error-recovery) |
| `CONFIG_ERROR` | 500 | Server is missing required configuration |

## Auth Errors

| Code | Status | Description |
|------|--------|-------------|
| `SIGNUPS_PAUSED` | 403 | `POST /v1/auth/create-account` is closed on this instance. Existing/invited users sign in with device login instead; everyone else needs an invite |
| `INVALID_CREDENTIAL` | 401 | Google One Tap token rejected or expired — sign in again |
| `EMAIL_NOT_VERIFIED` | 403 | Google hasn't verified that email |
| `SSO_REQUIRED` | 403 | The email's workspace enforces SSO — follow `redirect_url` |

Device login (`POST /v1/auth/device/token`) keeps the RFC 8628 token in `error` so
device-flow clients keep working, and adds `code` + `hint`:

| `error` | `code` | Meaning / next step |
|---------|--------|---------------------|
| `invalid_request` | `INVALID_REQUEST` | Body must be `{ "device_code": "…" }` |
| `invalid_grant` | `DEVICE_CODE_UNKNOWN` | Unknown or already-used code (the token is handed out once) — start a new login |
| `expired_token` | `DEVICE_CODE_EXPIRED` | The user didn't finish within 10 minutes — start a new login and send the new link |
| `access_denied` | `DEVICE_LOGIN_DENIED` | The user declined in the browser — ask, then start again |

## Artifact Errors

| Code | Status | Description |
|------|--------|-------------|
| `ARTIFACT_NOT_FOUND` | 404 | Artifact doesn't exist |
| `VERSION_NOT_FOUND` | 404 | Version doesn't exist |
| `SLUG_TAKEN` | 409 | Slug already in use |
| `INVALID_SLUG` | 400 | Slug format invalid |
| `VISIBILITY_HELD` | 202 | `PATCH` accepted but public visibility was held by instance policy (`OPEN_VISIBILITY_DISABLED`, publisher not in the rollout) — no paid entitlement involved. Visibility falls back to `workspace` (approval-gated) or `private`; response includes `message` and, for `POST /v1/publish`, a `notice` string instead — see [Error recovery](#error-recovery) |
| `MODERATION_HELD` | 202 | `PATCH` accepted but an automated content-safety check on the transition to `public` didn't clear instantly. Artifact stays `private`; response includes `message` and optional `reason`. Re-checked automatically within the hour and restored to `public` on its own — no re-publish needed. See [artifacts.md § Visibility](artifacts.md#patch-v1artifactsid) and [Error recovery](#error-recovery) |

## Data Errors

| Code | Status | Description |
|------|--------|-------------|
| `KEY_NOT_FOUND` | 404 | JSON key doesn't exist |
| `ROW_NOT_FOUND` | 404 | Table row doesn't exist |
| `TABLE_NOT_FOUND` | 404 | Table doesn't exist |
| `INVALID_FILTER` | 400 | Invalid query filter |
| `FILE_TOO_LARGE` | 413 | Dataset file exceeds the 500MB cap |
| `STORAGE_QUOTA_EXCEEDED` | 507 | Instance-wide storage cap reached — an operator setting (`STORAGE_QUOTA_BYTES`), unset by default (unlimited); delete data or ask the operator to raise it |

## Blob Errors

| Code | Status | Description |
|------|--------|-------------|
| `BLOB_NOT_FOUND` | 404 | Blob doesn't exist |
| `FILE_TOO_LARGE` | 413 | Exceeds 50MB per file (500MB/file for asset-library buckets) |
| `STORAGE_LIMIT_EXCEEDED` | 413 | Artifact storage full — 500MB/artifact (10GB/bucket for asset libraries) |
| `STORAGE_QUOTA_EXCEEDED` | 507 | Instance-wide storage cap reached — an operator setting (`STORAGE_QUOTA_BYTES`), unset by default (unlimited) |
| `BLOB_LIMIT_EXCEEDED` | 400 | Max 1000 blobs per artifact (10,000 for asset-library buckets) |
| `INVALID_TYPE` | 400 | MIME type not allowed |

## Collaborator Errors

| Code | Status | Description |
|------|--------|-------------|
| `CANNOT_REMOVE_OWNER` | 400 | Cannot remove artifact owner |
| `USER_NOT_FOUND` | 404 | Transfer target not a user |

## Email Errors

| Code | Status | Description |
|------|--------|-------------|
| `EMAIL_RATE_LIMITED` | 429 | Daily email cap |
| `CONFIG_ERROR` | 500 | Email binding missing |
| `INVALID_RECIPIENT` | 400 | Invalid email address |

## Job Errors

| Code | Status | Description |
|------|--------|-------------|
| `JOB_NOT_FOUND` | 404 | Job doesn't exist |
| `INVALID_REQUEST` | 400 | Covers several job-creation failures via a shared message, not a distinct code each: the 5-jobs-per-UTC-day limit (`Job limit reached (5 per user)`, per-user not per-artifact), and over 10 recipients on `email`/`asset_delivery` destinations (`Maximum 10 recipients per email` / `per delivery`) |
| `INVALID_SCHEDULE` | 400 | Invalid cron expression |
| `CONNECTION_MISSING` | 400 | Job names a connection (`query_snapshot`, `materialize`, `sheets_append`, Slack bot) that doesn't exist on the artifact or its workspace — check `sdk.connection` / workspace connectors before creating the job, not after |

## Comments Errors

| Code | Status | Description |
|------|--------|-------------|
| `COMMENTS_DISABLED` | 403 | Comments disabled |
| `COMMENT_NOT_FOUND` | 404 | Comment doesn't exist |
| `NAME_REQUIRED` | 400 | Author name required |
| `AUTH_REQUIRED` | 401 | Session required |
| `REPLIES_DISABLED` | 403 | Replies disabled |
| `MAX_DEPTH` | 400 | Reply depth limit |

## Proxy Errors

| Code | Status | Description |
|------|--------|-------------|
| `BLOCKED_DESTINATION` | 403 | URL blocked |
| `HOST_NOT_ALLOWED` | 403 | Host not in allowlist |
| `PROXY_RATE_LIMITED` | 429 | Rate limit exceeded |
| `FILE_TOO_LARGE` | 413 | Response exceeds 10MB |
| `PROXY_ERROR` | 502 | Upstream request failed |

## Sheets Errors

| Code | Status | Description |
|------|--------|-------------|
| `SHEETS_NOT_CONNECTED` | 401 | OAuth not completed |
| `SHEETS_ACCESS_DENIED` | 403 | Sheet not shared |
| `FETCH_ERROR` | 500 | Google Sheets API error |

## PWA Errors

| Code | Status | Description |
|------|--------|-------------|
| `INVALID_ICON` | 400 | Missing PNG signature |
| `INVALID_SHORT_NAME` | 400 | Short name > 12 chars |

## Error Recovery

What to actually do when you hit these, beyond retrying blindly:

**401 unauthorized** — read `reason`. `missing`: you forgot the header or have no key yet.
`invalid` / `revoked` / `expired`: the saved key is dead — don't retry it. Get a new one
(user opens `$ORIGIN/home?view=connect`, or device login — [auth.md](../auth.md)), save it,
retry once. Tell the user you need them to reconnect; never ask them to paste a key into chat.

**429 rate limited** (`RATE_LIMIT_EXCEEDED` on publish / account creation / AI, `RATE_LIMITED` on the data plane) — on publish (`POST
/v1/publish` and the session `/create` builder — both enforce the same cap), the body
and headers are actionable: `error` states the limit and reset time in words ("Daily
publish limit reached (100 per day). It resets at HH:MM UTC, in about N hours."), plus
`limit` / `remaining` / `reset` (unix seconds) / `retryAfter` (seconds) fields and
`X-RateLimit-Remaining` / `X-RateLimit-Reset` / `Retry-After` headers. Other surfaces
(AI chat, scheduled jobs) may only return the code — see the specific doc
([jobs.md](jobs.md), [team/workspace-assistant.md](../team/workspace-assistant.md)) for
their windows. Don't retry-loop past the limit — batch the work locally (build/validate
the full payload before making calls) and back off using `retryAfter`/`Retry-After` when
present, or wait for the stated reset.

**413 too large** (`FILE_TOO_LARGE` / `STORAGE_LIMIT_EXCEEDED` / `STORAGE_QUOTA_EXCEEDED`)
— check which cap: per-file (split the upload), per-artifact/per-bucket (delete unused
data or move heavy media to `sdk.blobs`/asset buckets instead of inline JSON), or the
instance-wide `STORAGE_QUOTA_BYTES` operator setting (only an operator can raise this —
don't tell the user to "upgrade," there's no plan to upgrade to; the message itself says
so: "ask your ShareOut admin to raise STORAGE_QUOTA_BYTES").

**Published, but private** (`visibility_downgraded: true` on a `201` from `POST
/v1/publish`) — the publish worked, the page is just not public. It happens when the
instance turned public links off (`OPEN_VISIBILITY_DISABLED`, `notice` says so), when the
account has no verified email (anonymous `create-account` accounts **always** publish
privately until an email is linked), when the public-artifact cap is reached, or during a
moderation hold. A publish that sends no `visibility` counts as asking for public, so it is
reported the same way (`requested_visibility: "public"`). Tell the user it's private and
why — never announce the link as public, and don't re-publish to "fix" it.

**Public artifact limit** — not an error at all: if the instance sets
`PUBLIC_ARTIFACT_LIMIT` and the account is at the cap, `POST /v1/publish` succeeds
(`201`) but silently publishes **privately** instead, with a `notice`: "Public artifact
limit reached (N per account). Published privately. Make another artifact private, or
ask your ShareOut admin to raise PUBLIC_ARTIFACT_LIMIT." Tell the user their page is
private, not that the publish failed.

**Visibility held** (`VISIBILITY_HELD` / `MODERATION_HELD`, both `202`) — these are not
failures, the write succeeded. Tell the user their page is "publishing shortly" / "under
automated review," not that it's broken or that they need to pay for anything:
- `VISIBILITY_HELD` — an operator has restricted public links on this instance and this
  publisher isn't in the rollout. Visibility fell back to `workspace` or `private`; only
  an instance operator can change the policy (`OPEN_VISIBILITY_DISABLED`).
- `MODERATION_HELD` — an automated content-safety check didn't clear instantly. It
  re-checks within the hour and goes public automatically — do not re-publish to "fix" it.

**No AI provider configured** — this instance has no platform AI key and the workspace
has no BYO key ([team/workspace-connections.md](../team/workspace-connections.md)). This
is a self-host configuration gap, not something the end user or a retry fixes. Two
different surfaces handle it differently:
- Visitor chat / pilot / admin-chat (raw REST): `INTERNAL_ERROR` (500), `message: "AI
  provider not configured (set VERCEL_AI_GATEWAY, ANTHROPIC_API_KEY or OPENAI_API_KEY)"`.
- The Home/workspace assistant ([team/workspace-assistant.md](../team/workspace-assistant.md)):
  no error at all — it replies in-thread, with an actionable "set this env var" message
  for admins and "ask your admin" for everyone else.

Either way, tell them to ask the instance operator to set a provider key or add a
workspace BYO key in Admin → AI — never suggest a billing upgrade.

## Related

- [Overview](overview.md) - API intro
