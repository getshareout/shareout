# Workspace API Reference

REST endpoints for ShareOut **workspace** capabilities. Load [SKILL.md](SKILL.md) first.
Prefix every path with `$ORIGIN` (see base skill).

There is no checkout and no plan API. Gate on **workspace role**
(`owner` / `admin` / `member`) and `GET $ORIGIN/v1/workspaces/{id}/features`.

## Authentication

All write/admin endpoints require:

```http
Authorization: Bearer {token}
```

Some workspace reads also accept a logged-in browser session.

Use a personal (`so_`) token for the routes on this page. Workspace Agent tokens and
external `sot_` tokens are accepted only by the artifact, publish, data and support
routes (which enforce their workspace boundary and scopes); every other route answers
them `403 INSUFFICIENT_SCOPE`.

## Features

```http
GET $ORIGIN/v1/workspaces/{id}/features
Authorization: Bearer {token}
```

If a needed feature is off, fix instance config or the feature flag — there is no
paid upgrade to sell.

## Members And Roles

Workspace roles:

| Role | Capability |
| --- | --- |
| `owner` | Full workspace control. |
| `admin` | Manage members, policy, subdomain, settings, workspace admin tasks. |
| `member` | Create/edit own artifacts; view workspace-visible artifacts. Create Team Space folders and rename/delete the ones they created, unless an admin turned [`members_can_create_folders`](#workspace-settings) off. |

Endpoints:

| Method | Endpoint | Notes |
| --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/members` | List members. |
| `POST` | `/v1/workspaces/{id}/members` | Add member; policy-gated. Re-posting an existing member updates their role (`member` or `admin`). |
| `DELETE` | `/v1/workspaces/{id}/members/{userId}` | Remove member. Also drops their Client (Sharee) links and `external_user` grants in this workspace — the membership edge alone does not gate grant access. |
| `POST` | `/v1/workspaces/{id}/members/invite` | Invite many people at once — see [Invite people](#invite-people). Existing members keep their role. |
| `GET` | `/v1/workspaces/{id}/members/metrics` | Member activity metrics. |
| `GET` | `/v1/workspaces/{id}/people` | Workspace people picker/list. |
| `POST` | `/v1/workspaces/{id}/logo` | Upload workspace logo (image). Admin+. |
| `DELETE` | `/v1/workspaces/{id}/logo` | Remove workspace logo. Admin+. |

### Invite people

Admin/owner only. Pass the addresses however the user gave them: an array, or **one
string** of pasted text (commas, newlines, `Name <email>`, a spreadsheet column).

```bash
curl -sS -X POST "$ORIGIN/v1/workspaces/$WS/members/invite" \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"emails":"Ana <ana@example.com>, luis@example.com\nbad@","role":"member","message":"Te sumo al equipo"}'
```

```json
{
  "results": [
    { "email": "bad@", "code": "invalid_email", "status": "skipped" },
    { "email": "ana@example.com", "code": "invited", "status": "invited", "email_sent": true },
    { "email": "luis@example.com", "code": "already_member", "status": "updated" }
  ],
  "summary": { "invited": 1, "added": 0, "already_member": 1, "invalid_email": 1, "domain_not_allowed": 0 }
}
```

- `code`: `invited` (got a 7-day join link) · `added` (had an account; added + notified) ·
  `already_member` (nothing changed) · `invalid_email` · `domain_not_allowed` (outside the
  [membership policy](#workspace-membership-policy)).
- `invite_url` appears only when the invite email did **not** go out (e.g. no email on the
  instance) — hand that link to the person.
- Max 100 valid addresses per call (`400 TOO_MANY_EMAILS`); split bigger lists.
- To change someone's role use `POST /v1/workspaces/{id}/members` `{ "email", "role" }`.
- Whole company domain instead of a list: set `allowed_domains` in the
  [membership policy](#workspace-membership-policy) — anyone signing in with that domain
  joins as a member, and `$ORIGIN/auth/login?redirect=/home?workspace={id}` is a link you
  can share with the team.

Seat usage: `GET /v1/workspaces/{id}` may include `seats: { used, limit, remaining }`.
On self-host, `limit` is typically unlimited / unset — do not invent seat paywalls.

## Workspace Settings

```http
GET   /v1/workspaces/{workspaceId}
PATCH /v1/workspaces/{workspaceId}
Authorization: Bearer {token}
Content-Type: application/json

{ "members_can_create_folders": false }
```

- `PATCH` requires `admin` or `owner` (`403 INSUFFICIENT_ROLE` otherwise); `GET` requires membership.
  It also takes `name`, `description` and `slug`; omit a field to leave it unchanged.
- `members_can_create_folders` (boolean, default `true`): when on, members create
  [Team Space folders](folders.md) and rename/delete the ones they created; folders made
  by someone else stay admin/owner-only. When off, only admins/owners create, rename or
  delete folders and members get `403 ADMIN_REQUIRED`. A non-boolean value is
  `400 VALIDATION_ERROR`. In the app: **Admin → General → Team Space folders**.

## Workspace Membership Policy

This controls who may join a workspace. It is not row-level artifact `access_policy`.

```http
GET /v1/workspaces/{workspaceId}/access-policy
Authorization: Bearer {token}
```

```json
{
  "allowed_domains": ["example.com"],
  "allowed_emails": ["audit@partner.com"]
}
```

Set policy:

```http
PUT /v1/workspaces/{workspaceId}/access-policy
Authorization: Bearer {token}
Content-Type: application/json

{
  "allowed_domains": ["example.com"],
  "allowed_emails": ["audit@partner.com"]
}
```

Rules:

- `GET` requires workspace membership.
- `PUT`/`PATCH` requires `admin` or `owner`.
- Omit a field to leave it unchanged.
- Send `[]` to clear a list.
- Invalid domains return `400 INVALID_DOMAIN`.
- Invalid emails return `400 INVALID_EMAIL`.
- Inviting an email outside policy returns `403 DOMAIN_NOT_ALLOWED` (bulk invite: per-email `code: "domain_not_allowed"`).
- Anyone who signs in with an email in `allowed_domains` auto-joins as `member`, so public
  mail providers (gmail.com, outlook.com, …) are refused with `400 PUBLIC_EMAIL_DOMAIN` —
  put individual addresses in `allowed_emails` instead.

## Subdomain

```http
GET /v1/workspaces/{workspaceId}/subdomain
POST /v1/workspaces/{workspaceId}/subdomain
DELETE /v1/workspaces/{workspaceId}/subdomain
```

Enable:

```http
POST /v1/workspaces/{workspaceId}/subdomain
Authorization: Bearer {token}
Content-Type: application/json

{ "enabled": true }
```

Requirements:

- Workspace role: `admin` or `owner`.
- Prefer `GET …/subdomain` → `eligible` / `can_manage` before enabling.
- On self-host, if not eligible, fix DNS / `SHAREOUT_BASE_URL` — do **not** offer a paid plan.
- If the API returns `402 TIER_REQUIRED` on self-host, treat as misconfiguration / bug.

## Session Policy

Per-workspace session lifetime.

```http
GET /v1/workspaces/{workspaceId}/session-policy
PUT /v1/workspaces/{workspaceId}/session-policy
```

```http
PUT /v1/workspaces/{workspaceId}/session-policy
Authorization: Bearer {token}
Content-Type: application/json

{ "session_max_days": 7 }
```

- `session_max_days`: integer `1`–`30`, or `null` to inherit the 30-day default.
- `GET` returns `{ session_max_days, platform_default_days: 30, eligible }`; requires membership.
- `PUT` requires `admin`/`owner`. On self-host, ignore plan/tier upgrade URLs if returned.
- A session is per-user and spans every subdomain, so login applies the **strictest** policy across the user's workspaces; you can only tighten below 30 days, never extend.

## Audit Log

Append-only governance trail. Admin/owner read only.

```http
GET /v1/workspaces/{workspaceId}/audit?limit=100
Authorization: Bearer {token}
```

```json
{
  "entries": [
    { "ts": "...", "actor_email": "admin@acme.co", "action": "member.remove",
      "target_type": "user", "target_id": "usr_123", "detail": { "removed_role": "member" } }
  ]
}
```

Records member add/remove, bulk invite, ownership transfer, subdomain enable/disable, membership-policy changes, connection create/delete, session-policy changes, and `members_can_create_folders` changes. Retained one year.

## Workspace Context

```http
GET    /v1/workspaces/{workspaceId}/context
PUT    /v1/workspaces/{workspaceId}/context
GET    /v1/workspaces/{workspaceId}/context/{name}
PUT    /v1/workspaces/{workspaceId}/context/{name}
DELETE /v1/workspaces/{workspaceId}/context/{name}
```

See [workspace-context.md](workspace-context.md).

## Workspace Connections

Full guide: [workspace-connections.md](workspace-connections.md) (shared vs **per-user** credentials, GraphQL, agent checklist).

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/connections` | Member+ | List connectors. Includes `credentialScope`, `hasMyCredentials` (per-user). No secrets. |
| `POST` | `/v1/workspaces/{id}/connections` | Admin+ | Create connector. `credentialScope`: `shared` (default) or `per_user`. |
| `GET` | `/v1/workspaces/{id}/connections/{connectionId}` | Admin+ | Detail + non-secret credential summary. |
| `DELETE` | `/v1/workspaces/{id}/connections/{connectionId}` | Admin+ | Delete connector (cascades member credentials). |
| `GET` | `/v1/workspaces/{id}/connections/{connectionId}/artifacts` | Member+ | Artifacts that have queried this connector. |
| `GET` | `/v1/workspaces/{id}/connections/{connectionId}/my-credentials` | Member+ | Per-user only: `{ configured, authType, updatedAt }`. |
| `PUT` | `/v1/workspaces/{id}/connections/{connectionId}/my-credentials` | Member+ | Save/update **your** token for a `per_user` connector. |
| `DELETE` | `/v1/workspaces/{id}/connections/{connectionId}/my-credentials` | Member+ | Remove **your** saved token. |
| `POST` | `/v1/workspaces/{id}/connections/test` | Admin+ | Verify pasted credentials before saving. |
| `PATCH` | `/v1/workspaces/{id}/connections/{connectionId}` | Admin+ | Toggle `agent_query_enabled` for workspace assistant. |
| `POST` | `/v1/home/agent/chat` | Member+ | Home agent chat (SSE). Body `{ text, threadId? }`. Requires `ai.web_agent`. |
| `POST` | `/v1/home/agent/transcribe?seconds=` | Member+ | Transcribe mic audio (raw body). Returns `{ text }`. Requires `ai.web_agent`. |
| `POST` | `/v1/home/agent/confirm` | Member+ | Confirm a pending Home agent action (JSON or SSE for builds). |
| `GET` | `/v1/home/agent/threads` | Member+ | List named chat threads. |
| `GET` | `/v1/home/agent/threads/{id}` | Member+ | Thread messages (`?before=` for pagination). |
| `POST` | `/v1/home/agent/threads/{id}/rename` | Member+ | `{ "title": "…" }`. |
| `DELETE` | `/v1/home/agent/threads/{id}` | Member+ | Delete a thread. |
| `GET` | `/v1/home/agent/media/{token}` | Member+ | Fetch assistant-attached media. |
| `POST` | `/v1/workspace/{id}/agent/chat` | Member+ | Workspace-scoped assistant chat (SSE, same as Home without canvas tools). |
| `POST` | `/v1/workspace/{id}/agent/confirm` | Member+ | Confirm a pending assistant action. |
| `GET` | `/v1/workspace/{id}/agent/threads` | Member+ | List threads (workspace scope). |
| `GET` | `/v1/workspace/{id}/agent/threads/{id}` | Member+ | Thread messages. |
| `POST` | `/v1/workspace/{id}/agent/threads/{id}/rename` | Member+ | Rename thread. |
| `DELETE` | `/v1/workspace/{id}/agent/threads/{id}` | Member+ | Delete thread. |
| `GET` | `/v1/workspace/{id}/agent/media/{token}` | Member+ | Fetch assistant-attached media. |
| `GET` | `/v1/workspaces/{id}/connections/{provider}/auth-url` | Admin+ | OAuth start URL. |
| `GET` | `/v1/workspaces/{id}/connections/{provider}/callback` | — | OAuth callback. |
| `GET` | `/v1/workspaces/{id}/connections/{connection}/slack/channels` | Member+ | Slack channel list. |
| `GET` | `/v1/oauth/slack/callback` | — | Slack OAuth callback. |

### Create shared generic connector

```json
POST /v1/workspaces/{id}/connections
{
  "name": "team_api",
  "type": "rest_api",
  "credentialScope": "shared",
  "config": { "baseUrl": "https://api.example.com" },
  "credentials": { "type": "api_key", "data": { "apiKey": "…" } }
}
```

### Create per-user connector (GraphQL, personal API keys)

Admin defines endpoint; **do not** send `credentials.data`:

```json
POST /v1/workspaces/{id}/connections
{
  "name": "acme_graphql",
  "type": "rest_api",
  "credentialScope": "per_user",
  "authType": "api_key",
  "config": {
    "baseUrl": "https://api.example.com/graphql",
    "apiKeyHeader": "Authorization",
    "apiKeyPrefix": "Bearer "
  }
}
```

Each member saves their token:

```json
PUT /v1/workspaces/{id}/connections/{connectionId}/my-credentials
{
  "credentials": { "type": "api_key", "data": { "apiKey": "member-token" } }
}
```

Artifacts query with `sdk.connection('acme_graphql')` — see [../sdk/live-data.md](../sdk/live-data.md).

**Errors:** `403 CREDENTIALS_REQUIRED` when a member queries before saving `my-credentials`. `400 NOT_PER_USER` when calling `my-credentials` on a shared connector.

## Workspace Schedules And Automations

Workspace admins can manage jobs/crew triggers across artifacts:

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/schedules` | List all workspace schedules. |
| `GET` | `/v1/workspaces/{id}/schedules/{jobId}/logs` | Recent schedule logs. |
| `POST` | `/v1/workspaces/{id}/schedules/{jobId}/run` | Run now. |
| `PATCH` | `/v1/workspaces/{id}/schedules/{jobId}` | Enable/disable. |
| `DELETE` | `/v1/workspaces/{id}/schedules/{jobId}` | Delete schedule. |
| `GET` | `/v1/workspaces/{id}/automations` | List crew triggers. |
| `GET` | `/v1/workspaces/{id}/automations/{triggerId}/runs` | Run history. |
| `POST` | `/v1/workspaces/{id}/automations/{triggerId}/run` | Dispatch now. |
| `PATCH` | `/v1/workspaces/{id}/automations/{triggerId}` | Any of `enabled`, `cron` (the trigger) and `name` (1–120 chars), `instructions` (1–20000), `model` (a crew model id), `maxIterations`, `runBudgetMicroUsd` (the task; caps bounded as on `PATCH /crew`). Only sent fields change; a bad `cron` saves nothing. `400 INVALID_REQUEST` on a bad field. Admin+. |
| `DELETE` | `/v1/workspaces/{id}/automations/{triggerId}` | Delete trigger. |

Job payloads are documented in [../api/jobs.md](../api/jobs.md).

## Run Inspector

Unified run detail across crew, scheduled job, and metric-alert surfaces. Admin+ only. Full guide: [admin-portal.md](admin-portal.md#run-inspector).

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/runs?surface=&status=&limit=` | List recent runs (`surface`: `crew` \| `job` \| `alert`; `status`: `success` \| `failed`). |
| `GET` | `/v1/workspaces/{id}/runs/{surface}/{runId}` | Run detail — steps, tokens, cost, delivery, `rerunPath` when re-runnable. |

## Admin Artifact Governance

| Method | Endpoint | Who | Description |
| --- | --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/admin/artifacts` | Admin+ | Governance table (owner, visibility, views, size, perf, paused). |
| `POST` | `/v1/workspaces/{id}/admin/artifacts/{artifactId}/pause` | Admin+ | `{ "paused": true \| false }`. |
| `POST` | `/v1/workspaces/{id}/admin/artifacts/{artifactId}/visibility` | Admin+ | `{ "visibility": "…" }`. |
| `POST` | `/v1/workspaces/{id}/admin/artifacts/{artifactId}/transfer` | Admin+ | `{ "email": "…" }` — reassign owner (must be workspace member). |

## Pending Invites

| Method | Endpoint | Who | Description |
| --- | --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/invites` | Admin+ | List unclaimed invites. |
| `DELETE` | `/v1/workspaces/{id}/invites/{inviteId}` | Admin+ | Revoke pending invite. |
| `POST` | `/v1/workspaces/{id}/invites/{inviteId}/resend` | Admin+ | New join link → `{ ok, inviteUrl }`. Default emails it and expires older links; `{ "notify": false }` only returns the link (copy/paste, older links stay valid). |

## Workspace Shared Tables

Share one artifact's table with the workspace so other artifacts read/write it. Full guide: [workspace-tables.md](workspace-tables.md).

| Method | Endpoint | Who | Description |
| --- | --- | --- | --- |
| `POST` | `/v1/data/{artifactId}/workspace/_share` | Artifact owner | Share `{ table, as?, access: read\|readwrite }`. |
| `DELETE` | `/v1/data/{artifactId}/workspace/_share/{sharedName}` | Artifact owner | Stop sharing. |
| `GET` | `/v1/data/{artifactId}/workspace/_shares` | Any member artifact | Shares visible in the workspace. |
| `GET\|POST\|PATCH\|DELETE` | `/v1/data/{artifactId}/workspace/tables/{sharedName}/…` | Member artifact | Read (always) / write (only if `readwrite`) a shared table. |
| `GET` | `/v1/workspaces/{id}/shared-tables` | Any member | Workspace-wide shared-table catalog (Datasets tab). |

## Workspace Publish Governance

Gate when **members** take workspace artifacts to public visibility. Full guide: [publish-governance.md](publish-governance.md).

| Method | Endpoint | Who | Description |
| --- | --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/publish-policy` | Any member | Current `policy` + `approvals_required`. |
| `PATCH` | `/v1/workspaces/{id}/publish-policy` | `admin`/`owner` | Set `allow`, `prohibit`, or `require_approval`. |
| `GET` | `/v1/workspaces/{id}/publish-approvals` | Any member | List approval requests (`?status=pending`); rows include `approvals_required`, `approved_count`, `artifact_slug`, `viewer_can_decide`. |
| `POST` | `/v1/artifacts/{id}/publish-approval` | Member requester | Nominate approvers; `visibility` + `approver_ids`. |
| `POST` | `/v1/artifacts/{id}/publish-approval/{requestId}/decision` | Nominated approver | `{ "decision": "approve" \| "reject" }`. |

Publish/PATCH responses may include `notice` and `approval_required: { required, artifact_id, visibility?, workspace_id? }` when the gate holds visibility at `workspace`. `PATCH /v1/artifacts/{id}` with open visibility returns **202** with the same `approval_required` shape.

## Skill Marketplace

Per-workspace catalog of `artifact_type: "skill"` markdown playbooks. Full guide: [skill-marketplace.md](skill-marketplace.md). On self-host, available when the instance exposes the marketplace (no paid plan required).

| Method | Endpoint | Who | Description |
| --- | --- | --- | --- |
| `GET` | `/v1/skills/recommended` | Signed-in user | Official **Recommended by ShareOut** strip (workspace-agnostic). |
| `GET` | `/v1/workspaces/{id}/skills` | Member | Browse/rank (`?sort=top\|trending\|new`, `category`, `q`). |
| `GET` | `/v1/workspaces/{id}/skills/categories` | Member | Category list. |
| `GET` | `/v1/workspaces/{id}/skills/installed` | Member | Saved "My Skills" list. |
| `POST` | `/v1/artifacts/{skillId}/skill/vote` | Member | Upvote (idempotent). |
| `DELETE` | `/v1/artifacts/{skillId}/skill/vote` | Member | Remove vote. |
| `POST` | `/v1/artifacts/{skillId}/skill/install` | Member | Save to My Skills. |
| `DELETE` | `/v1/artifacts/{skillId}/skill/install` | Member | Unsave. |
| `GET` | `/v1/artifacts/{artifactId}/skills` | `editor`+ | List attached skills. |
| `POST` | `/v1/artifacts/{artifactId}/skills` | `editor`+ | Attach `{ skill_artifact_id, position }` (max 5). |
| `POST` | `/v1/artifacts/{artifactId}/skills/{skillId}` | `editor`+ | Bump attachment to latest skill version. |
| `DELETE` | `/v1/artifacts/{artifactId}/skills/{skillId}` | `editor`+ | Detach. |
| `PATCH` | `/v1/artifacts/{skillId}/skill/admin` | `admin`/`owner` | `{ featured }` or `{ blocked }`. |
| `GET` | `/v1/skills/{skillId}/markdown` | Signed-in | Raw `SKILL.md` for in-Studio viewer (official or visible skill). |
| `GET` | `/v1/workspaces/{scope}/agent-skills` | Member | Skills attached to caller's assistant (`scope` = workspace id or `__personal`). |
| `POST` | `/v1/workspaces/{scope}/agent-skills` | Member | Attach skill to caller's assistant (max 8). |
| `DELETE` | `/v1/workspaces/{scope}/agent-skills/{skillId}` | Member | Detach from caller's assistant. |
| `GET` | `/v1/workspaces/{ws}/ai-limits` | Member | Today's in-artifact agent usage: yours, the workspace automation total and daily cap, and (owner/admin) every member. Also the monthly AI budget: `month_spend_usd`, `budget_usd`, `pct`, `budget_state` (`none`/`ok`/`near`/`reached`), `budget_resets_at`, and (owner/admin) `spend_by_kind`. Money is at the workspace's price (cost × its AI markup); platform admins also get `operator: { cost_usd, margin_usd, markup }`. |
| `PUT` | `/v1/workspaces/{ws}/llm/budget` | Owner/admin | Set the monthly AI budget `{"monthlyBudgetUsd": 100}` (above 0, up to 100000) or `null` to remove it. It caps every metered AI call of the workspace (chat, automations, Knowledge, summaries); once reached, new calls are refused with code `workspace_budget` until `budget_resets_at` (first of next month, UTC). Embeddings, search, transcription and publish checks are never blocked. Measured at the workspace's price (cost × AI markup). |
| `GET` | `/v1/workspaces/{ws}/invoices` | Owner/admin | Invoices the instance operator issued to this workspace (drafts only for platform admins), with `can_manage`. Each has `number`, `status` (`draft`/`open`/`paid`/`void`), `total_cents`, `currency`, `lines` (a usage line carries its `usage` breakdown by kind, model and member at `price_micro_usd`; platform admins also get `cost_micro_usd` and `markup_bps`, plus `markup` on the list), `notes` (how to pay), `due_at`, `receipt` (the invoice document), `proof`, `paid_source` (`operator`/`proof`/`email`), `emailed_at`, `emailed_to`. Platform admins also get `delivery` — `{ to, source: "billing_email"\|"admins", suppressed, email_enabled }`: exactly who issuing emails. |
| `POST` | `/v1/workspaces/{ws}/invoices` | Platform admin | `{ "lines": [{"description","unit_cents","quantity"?}], "usage_month"?: "YYYY-MM", "status"?: "draft"\|"open", "currency"?, "due_at"?: "YYYY-MM-DD", "notes"?, "number"? }`. `usage_month` must be a closed month and adds its metered AI usage (USD) as a line, at cost × the workspace's AI markup; 409 if that month is already on a non-void invoice. Number defaults to `INV-YYYY-NNNN`, or takes the one your tax system printed (letters, digits, spaces, `. _ / - #`). With `"status": "open"` it is emailed unless `"send_email": false`; the response then has `email` `{ sent, to, suppressed, code?, error? }`. |
| `POST` | `/v1/workspaces/{ws}/invoices/from-document?number=…&total_cents=…&description=…` | Platform admin | One step from the invoice you issued in your own tax system: raw PDF/PNG/JPG/WEBP body (≤10 MB, bytes checked) becomes the `receipt`. Query: `number` (as printed), `total_cents` and `description` (the one line) required; `currency`, `period_month`, `due_at`, `notes`, `status`, `send_email`, `name` optional. 409 when the number is taken. |
| `GET` | `/v1/workspaces/{ws}/invoices/usage?month=YYYY-MM` | Platform admin | Preview a closed month's AI usage line and breakdown before billing it. |
| `PATCH` | `/v1/workspaces/{ws}/invoices/{id}` | Platform admin | `{ "status": "open"\|"paid"\|"void", "payment_reference"?, "paid_at"?: "YYYY-MM-DD", "notes"?, "due_at"? }`. draft→open issues it and emails it unless `"send_email": false`; open→paid (`paid_source: "operator"`); paid→open undoes; draft/open→void. `DELETE` removes a draft. |
| `POST` | `/v1/workspaces/{ws}/invoices/{id}/send` | Platform admin | Email an unpaid invoice again. 409 when nobody can receive it (no billing email or owner/admin, or all suppressed), 503 without an `EMAIL` binding. |
| `PUT` | `/v1/workspaces/{ws}/invoices/{id}/receipt` · `/proof` | Platform admin · owner/admin | Raw PDF/PNG/JPG/WEBP body (≤10 MB, bytes checked), `?name=` for the file name. Proof only while the invoice is `open`; a proof from an owner/admin marks it paid (`paid_source: "proof"`) and emails the platform admins with it. `GET` the same path downloads it. |
| `GET` · `PUT` | `/v1/workspaces/{ws}/ai-markup` | Platform admin | The workspace's AI resale markup: `{ markup, workspace_markup, instance_default }`. PUT `{ "markup": 1.5 }` (1–10) or `{ "markup": null }` for the instance default (`PUT /v1/admin/ai-settings {"defaultMarkup": 1.5}`). Every AI amount the workspace sees — budget, Usage, invoices, crew and Knowledge costs — is cost × this; it never sees cost or the markup. |
| `GET` | `/v1/workspaces/{ws}/spend?month=YYYY-MM[&format=csv]` | Owner/admin | Admin → Billing spend: per day and per metric (storage, serving, automations, AI, email, browser), month-end pace and last month's total; `format=csv` downloads it. AI metrics at the workspace's price, live from the AI meter; infra metrics from the nightly ledger. `400 INVALID_MONTH`. |
| `GET` | `/v1/workspaces/{ws}/ai-report?month=YYYY-MM[&format=csv]` | Owner/admin | Admin → Billing → AI report: one month of AI at the workspace's price, by category, kind, model (input/output tokens), automation, page, person and day. Same total as the budget and the invoice. `400 INVALID_MONTH`. Agent tokens refused. |
| `GET` | `/v1/workspaces/{ws}/summary?month=YYYY-MM` | Owner, listed admins | Admin → Summary: one month's usage (visits, pages, knowledge, AI, per member, readers outside the team) plus `can_manage`. Default: this month. `400 INVALID_MONTH`; `403` for admins the owner did not list. Agent tokens refused. |
| `GET` | `/v1/workspaces/{ws}/summary/access` | Member | `{ can_view, can_manage }` — drives whether the Summary entry shows. |
| `GET` · `PUT` | `/v1/workspaces/{ws}/summary/viewers` | Owner | GET: owner + admins, each with `can_view`, and `max` (50). PUT `{ "user_ids": ["usr_…"] }` replaces who besides the owner may view; only admins of the workspace; written to the audit log (`summary.viewers_update`). |
| `GET` · `PUT` | `/v1/workspaces/{ws}/billing-profile` | Owner/admin | Who invoices are made out to: `{ profile \| null, can_edit, tax_conditions }`. PUT the whole profile — `country`, `legal_name`, `tax_id` (CUIT checked for `AR`), `tax_condition` (`responsable_inscripto`/`monotributo`/`exento`/`consumidor_final`), `address`, `city`, `province`, `postal_code`, `phone`, `billing_email`; `400 VALIDATION_ERROR` with `fields` per refused field. Audited (`billing_profile.update`). Agent tokens refused. |
| `GET` | `/v1/workspaces/{ws}/default-skills` | Member | Skills attached to every member's assistant in this workspace. |
| `POST` | `/v1/workspaces/{ws}/default-skills` | Admin | `{ "skill_artifact_id" }`: attach a workspace-visible Library skill to every member's assistant (max 5; injected only for turns scoped to this workspace; re-POST re-pins to the latest version). |
| `DELETE` | `/v1/workspaces/{ws}/default-skills/{skillId}` | Admin | Remove it. |

Publish a skill via `POST /v1/publish` with `artifact_type: "skill"` and `workspace_id`. Attach at publish with `attached_skill_ids` on non-skill artifacts.

**Invoice email.** Issuing sends the invoice to the billing profile's `billing_email`, else to the workspace's internal owners and admins — never to a suppressed address — with the document attached, its total, due date and how to pay, and a link to Admin → Billing. It replies to `invoice+<token>@<inbox domain>`: a reply that passes DMARC, comes from the billing email or an owner/admin and carries a PDF/PNG/JPG/WEBP (≤10 MB) becomes the proof and marks the invoice paid (`paid_source: "email"`). Anything else changes nothing and the platform admins get a note to review it. Agent tokens can never issue, send or mark an invoice paid.

## External Sharing

Share folders and artifacts **outside** the workspace with typed Client orgs (clients, suppliers, partners, investors). External members are free. Full guide: [external-sharing.md](external-sharing.md). On self-host, available when the instance enables external sharing — do not treat as a paid upsell.

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/sharees` | Admin+ | List Clients. |
| `POST` | `/v1/workspaces/{id}/sharees` | Admin+ | Create Client `{ name, type }`. |
| `GET/PATCH/DELETE` | `/v1/workspaces/{id}/sharees/{sid}` | Admin+ | Read/update/delete Client (branding, properties). |
| `GET/POST/DELETE` | `/v1/workspaces/{id}/sharees/{sid}/members[/{uid}]` | Admin+ | Invite/remove external members. |
| `GET/POST/DELETE` | `/v1/workspaces/{id}/grants[/{gid}]` | Admin+ | Folder/artifact/**file** grants (`view`/`comment`/`create`/`edit`). A folder's manager (its creator, while members manage their folders) may also `GET ?resource_type=folder&resource_id=…` and `DELETE` grants on that folder. `POST` needs the external-sharing entitlement; `GET` and `DELETE` do not. |
| `POST` | `/v1/workspaces/{id}/share-person` | Admin+ (or the folder's manager) | Share one file/folder with one outside email — `{ email, resource_type, resource_id, capability, expires_in_days?, expires_at? }`; re-share replaces the expiry. Admins and managers alike need the entitlement (`403 EXTERNAL_SHARING_NOT_ENTITLED`) and an email the workspace's allowed domains accept (`403 DOMAIN_NOT_ALLOWED`). |
| `GET/POST/DELETE` | `/v1/workspaces/{id}/sharees/{sid}/members/{uid}/tokens[/{tid}]` | Admin+ | Scoped external `sot_` tokens (never `artifacts:publish`). |
| `GET` | `/v1/workspaces/{id}/sharees/{sid}/activity` | Admin+ | Read receipts for one Client. |
| `GET` | `/v1/workspaces/{id}/sharee-activity` | Admin+ | Read receipts across all Clients. |
| `GET` | `/v1/workspaces/{id}/folders/{fid}/activity` | Folder manager | Who opened what across one folder's subtree (max 100). |
| `GET/PUT/DELETE` | `/v1/workspaces/{id}/sharees/{sid}/context[/{name}]` | Member read / admin write | Per-client private notes (AI memory). |

External members browse granted pages and files at **`GET /shared`** (branded portal); **`/shared?folder=<id>`** is one folder's client portal, where a folder invite's join link lands. If create returns `403 EXTERNAL_SHARING_NOT_ENTITLED` on self-host, treat as feature/config — not a plan to buy: the **External sharing** feature (`collab.external_sharing`) is off for that workspace.

## Workspace Library

Private, versioned JS modules imported like a CDN lib. Full guide: [libraries.md](libraries.md).

| Method | Endpoint | Who | Description |
| --- | --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/libraries` | Member | Workspace module catalog. |
| `GET` | `/v1/me/libraries` | Owner | Personal module catalog. |
| `POST` | `/v1/me/libraries` | Owner | Publish a module (session): `{ name, version, scope, workspace_id?, main, exports, js, readme }`. |
| `GET` | `/v1/artifacts/{id}/lib/{name}` | public | Resolve a module name → pinned-or-latest import URL for this artifact. |
| `GET` | `/v1/artifacts/{id}/libs` | `viewer`+ | List the artifact's version pins. |
| `POST` | `/v1/artifacts/{id}/libs` | `editor`+ | Pin `{ name, version? }` (defaults to latest). |
| `DELETE` | `/v1/artifacts/{id}/libs/{name}` | `editor`+ | Remove a pin. |

Publish via the token API with `POST /v1/publish`, `artifact_type: "library"`, `entrypoint: "README.md"`, and a `library: { version, main, exports }` block (omit `workspace_id` for a personal module). Versions are immutable — re-publishing a semver returns `409 LIBRARY_VERSION_EXISTS`. Modules serve at `/lib/<workspace-slug>/<name>@<semver>.js` (workspace) or `/lib/@u/<user-handle>/<name>@<semver>.js` (personal). Import with `await so.lib('<name>')`.

## Metric Alerts In Workspaces

Metric alert endpoints stay under `/v1/metric-alerts`; workspace role changes permissions.

| Role | Capability |
| --- | --- |
| Artifact owner/editor or workspace `owner`/`admin` | Define metrics, create alerts to any destination, manage every alert on the artifact. |
| Workspace `member` or viewer collaborator | Self-subscribe only to personal destinations. |

Full reference: [../api/metric-alerts.md](../api/metric-alerts.md).

## Direct Messages

One-to-one messages between internal members of a workspace (Home's Messages menu, the assistant, MCP and this API share the rules). Workspace agent tokens are refused.

| Method | Endpoint | Notes |
| --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/messages` | Your conversations, most recent first, with unread counts (`?unread=1`, `?limit`). |
| `POST` | `/v1/workspaces/{id}/messages` | Send `{to, text, artifact_id?}`; `to` = name, email or user id (409 `RECIPIENT_AMBIGUOUS` lists `candidates`). |
| `GET` | `/v1/workspaces/{id}/messages/unread` | `{ unread }` for a badge. |
| `GET` | `/v1/workspaces/{id}/messages/people` | Who you can write to. |
| `GET` | `/v1/workspaces/{id}/messages/with/{userId}` | One conversation, newest first (`?before`, `?limit`). |
| `POST` | `/v1/workspaces/{id}/messages/with/{userId}/read` | Mark it read. |

Full reference: [messages.md](messages.md).

## Home Activity

Activity feed and visibility settings for the redesigned workspace Home. Full guide: [activity-feed.md](activity-feed.md).

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `GET` | `/v1/home/activity-feed?workspace=&window=&limit=` | Member+ | Needs You + Pulse (`window`: `today`, `7d`, `30d`). Returns `needs`, `seen` (dismissed/opened needs still in window), `pulse`, `actionItems`, `requestedOpen`. |
| `GET` | `/v1/home/agent/brief?workspace=` | Member+ | Proactive daily AI catch-up (`ai.web_agent` required). |
| `GET` | `/v1/home/event-visibility?workspace=` | Member+ | Per-kind audience config; `canManage` for admins. |
| `PUT` | `/v1/home/event-visibility?workspace=` | Admin+ | `{ "kind", "audience" }` — `self`, `members`, `admins`, or `off`. |
| `GET` | `/v1/home/onboarding?workspace=` | Member+ | Setup checklist status (`track`, `tasks`, `pct`, `eligible`, `dismissed`, `celebrated`) or `{ "track": null }` for externals / ineligible. |
| `POST` | `/v1/home/onboarding/dismiss` | Member+ | Hide the checklist for this user+workspace. |
| `POST` | `/v1/home/onboarding/skill-ack` | Member+ | Mark the "Get the skill" task done (not server-observable otherwise). |
| `POST` | `/v1/home/onboarding/celebrate` | Member+ | One-shot 100% celebration marker (client fires when showing the moment). |
| `POST` | `/v1/home/dismiss-event` | Member+ | Hide Needs You events for the signed-in user (`{ "eventId" }` or `{ "eventIds": [] }`). Used by the notifications panel (dismiss, mark-all-read, or opening a card). |
| `GET` | `/v1/artifacts/{id}/presence` | Owner/collaborator+ | Live concurrent viewer count (best-effort). |

## Search

Ranked, typo-tolerant workspace search — same engine as the Home **⌘K** palette and the workspace assistant's **`search_workspace`** tool. Full reference: [../api/search.md](../api/search.md).

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `GET` | `/v1/search?q=&groups=&limit=&workspace=` | Token/session | Pages, folders, datasets, connectors, people, schedules, crew, alerts. `sot_` tokens auto-scope to their workspace. |
| `GET` | `/v1/home/search-index?workspace=` | Session | Compact index the palette ranks locally; `ETag` / `If-None-Match` → `304`. |
| `GET` | `/v1/home/deep-search?q=&workspace=` | Session | Page text, Knowledge passages and the groups the index does not carry. |
| `GET` `POST` `DELETE` | `/v1/home/recent-searches?workspace=` | Session | Your recent palette searches (max 20 per workspace); `POST { q }` records, `DELETE ?q=` removes one, `DELETE` clears. |

## Features

```http
GET /v1/workspaces/{workspaceId}/features
Authorization: Bearer {token}
```

Any member may view enabled/disabled workspace features. Workspace feature flags are read-only to normal users.

## Assets

Per-scope asset library: upload reusable files, group into versioned **deliverables**, bundle **collections**, and share WeTransfer-style download pages at `/d/<token>`. Personal scope uses `/v1/assets`; workspace scope uses `/v1/workspaces/{id}/assets` (any member). Full guide: [assets.md](assets.md).

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `GET` | `/v1/assets` or `…/workspaces/{id}/assets` | Member | List deliverables, loose blobs, bucket usage. |
| `POST` | `…/assets/upload` → `PUT …/_upload/{token}` | Member | Two-step upload. |
| `POST` | `…/assets/deliverables` | Member | `{ blobId, name, visibility? }` → versioned deliverable. `visibility`: `team` (default — workspace members only; bytes need a signed-in member), `private` (owner + direct shares), `workspace` (anyone with the link — use this for files embedded in artifacts). |
| `POST` | `…/assets/deliverables/{id}/version` | Member | Add a new version. |
| `POST` | `…/assets/collections` | Member | Bundle deliverables. |
| `POST` | `…/assets/collections/{id}/share` | Member | `{ expiresAt?, gate?, password?, domains? }` → `/d/<token>`. |
| `POST` | `…/assets/collections/{id}/send` | Member | Email the link to a recipient. |
| `GET` | `…/assets/links` | Member | List sent links (gate, expiry, views, revoked). |
| `POST` | `…/assets/links/{linkId}/revoke` | Member | Revoke a link (page + bytes 404). |
| `GET` | `/v1/files/{deliverableId}/content` | Session/token | Latest file bytes; owner, member (workspace files), or sharee grant. |
| `POST` | `/v1/workspaces/{id}/share-person` | Admin+ | `{ email, resource_type: "file"\|"folder", resource_id, capability: "view"\|"comment" }`; `409` if internal member. |

**Gate values:** `none` (default), `password` (+ `password`), `domain` (+ `domains[]`). Gated bytes stream via `/d/<token>/file/<blobId>` after the viewer clears the gate. First open notifies the sender by email (deduped on 0→1 views).

SDK: [../sdk/files.md](../sdk/files.md) — `sdk.files.getUrl('dlv_…')`.

## Workspace Knowledge

Opt-in learned library. Full guide: [knowledge.md](knowledge.md). On self-host, `enable` / `backfill` follow admin role + feature flags — not a paid plan.

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `GET` | `/v1/workspaces/{id}/knowledge` | Member+ | Settings + counts. |
| `GET` | `/v1/workspaces/{id}/knowledge/status` | Member+ | Training progress (24h window) + `corpus`: per-source `status` (`queued`/`ready`/`failed`/`unsupported`), `version`, `chunker_version`, `chunks`, `chunks_with_page`, `chunks_with_anchor`, `error` (members: only sources they may open). Instance admins too. |
| `GET` | `/v1/workspaces/{id}/knowledge/tree` | Member+ | Note summaries by kind. |
| `GET` | `/v1/workspaces/{id}/knowledge/files/{path}` | Member+ | One note (full body) + `source_artifacts` `[{ id, slug, title, url, available }]`. |
| `GET` | `/v1/workspaces/{id}/knowledge/from/{artifactId}` | Member+ | Notes learned from one artifact `{ enabled, notes: [{ path, kind, id, title }] }`; empty when you can't open it. |
| `PUT` | `/v1/workspaces/{id}/knowledge/files/{path}` | Member+ (`index.md`: Admin+) | Upsert note markdown. |
| `DELETE` | `/v1/workspaces/{id}/knowledge/files/{path}?forget=1` | Admin+ | Delete; `forget=1` stops re-learn. |
| `POST` | `/v1/workspaces/{id}/knowledge/enable` | Admin+ | `{ "enabled": true }`. |
| `POST` | `/v1/workspaces/{id}/knowledge/reindex` | Admin+ | Re-learn every page/File (or `{ "artifactIds": [...] }`) even at an unchanged version → `202 { queued, remaining, skipped }`. Once per workspace per 10 min (`429` + `Retry-After`). Instance admins too. |
| `POST` | `/v1/workspaces/{id}/knowledge/backfill` | Admin+ | Queue up to 200 pages for notes + every page and File for search → `{ queued, kicked, corpus, corpusRemaining }`. |
| `GET` | `/v1/workspaces/{id}/knowledge/search?q=&limit=&full=1&format=md` | Member+ | Cited passages from Files and pages. `full=1` returns whole passages instead of 700-char snippets. |
| `GET` | `/v1/workspaces/{id}/knowledge/sources?limit=` | Member+ | Learned sources: counts by status + recent list. |
| `GET` | `/v1/workspaces/{id}/knowledge/entities?type=&q=&status=&limit=` | Member+ | Entities (clients, people, products…) by mentions; `status=confirmed\|draft`. |
| `GET` | `/v1/workspaces/{id}/knowledge/entities/{entityId}?format=md` | Member+ | One entity: facts, relations, quoted mentions. |
| `POST` | `/v1/workspaces/{id}/knowledge/entities` | Admin+ | Add an entity `{ name, type, description?, aliases? }`, confirmed by the team → `201 { id }`. A name another entity goes by → `409 CONFLICT` + merge `suggestion`. |
| `PATCH` | `/v1/workspaces/{id}/knowledge/entities/{entityId}` | Admin+ | Rename (old name stays an alias), retype, `description`, `aliases`, or `{ "confirm": true }`. |
| `DELETE` | `/v1/workspaces/{id}/knowledge/entities/{entityId}?reason=` | Admin+ | Discard: gone, and never learned again until restored. `reason`: `noint`, `wrong`, `notent`, `dup`. |
| `POST` | `/v1/workspaces/{id}/knowledge/entities/{entityId}/merge` | Admin+ | `{ into }`: fold this entity into the one kept. |
| `POST` | `/v1/workspaces/{id}/knowledge/entities/{entityId}/facts` | Admin+ | The team states a fact `{ predicate, value, unit? }` → `201 { id }`. |
| `POST` | `/v1/workspaces/{id}/knowledge/relations` | Admin+ | Connect `{ from, type, to }` (entity ids) → `201 { id }`. |
| `POST` / `DELETE` | `/v1/workspaces/{id}/knowledge/relations/{relationId}[/confirm]` | Admin+ | Confirm a learned connection, or discard it (`?reason=`). |
| `POST` / `DELETE` | `/v1/workspaces/{id}/knowledge/facts/{factId}[/confirm]` | Admin+ | Confirm a learned fact (it becomes the team's value), or discard it. |
| `GET` / `PUT` | `/v1/workspaces/{id}/knowledge/schema` | Member+ / Admin+ | The team's types and `teamOnly`; `PUT { teamOnly }`. Admins also get learned types with counts and `relationTypes`. |
| `PUT` / `DELETE` | `/v1/workspaces/{id}/knowledge/schema/types/{type}` | Admin+ | Set `{ description?, ignored? }` on one of the team's types, or remove it. |
| `GET` / `POST` | `/v1/workspaces/{id}/knowledge/rules` | Member+ / Admin+ | Glossary and rules the learner reads first; `POST { kind: rule\|glossary, term?, text }`. |
| `DELETE` | `/v1/workspaces/{id}/knowledge/rules/{ruleId}` | Admin+ | Remove a rule or glossary term. |
| `GET` | `/v1/workspaces/{id}/knowledge/discarded?limit=` | Admin+ | What the team discarded, each with `kind` + `key`. |
| `POST` | `/v1/workspaces/{id}/knowledge/discarded/restore` | Admin+ | `{ kind, key }`: Knowledge may learn it again. |
| `GET` | `/v1/workspaces/{id}/knowledge/history?entity=&limit=` | Admin+ | The team's changes to the graph, newest first. |
| `GET` | `/v1/workspaces/{id}/knowledge/graph?focus=&depth=&limit=` | Member+ | Knowledge graph nodes + edges. |
| `GET` | `/v1/workspaces/{id}/knowledge/usage?days=30` | Admin+ | Metered Knowledge cost (AI, storage, vectors), micro-USD, tracking only. |

## Artifact delivery (one-shot)

One-shot send from the Home Inspector's **Automate** tab → **Send now** (editors) or the API — email, Slack, or Telegram. Uses the same `config` shapes as [jobs](../api/jobs.md). Full UI flow: [../core/workspace-home.md](../core/workspace-home.md#inspector-right-rail).

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `GET` | `/v1/artifacts/{id}/deliver` | Collaborator+ | Per-channel status (`telegram.linked`, `slack.connected` + `connectUrl`, `email.available`). |
| `GET` | `/v1/artifacts/{id}/deliver/slack-channels` | Collaborator+ | Searchable channel list for the workspace Slack connection. |
| `POST` | `/v1/artifacts/{id}/deliver` | Collaborator+ | `{ "action": "email" \| "slack" \| "telegram", "config": {…} }`. Viewers may only deliver to themselves on Slack/Telegram. |

See also [../integrations/slack.md](../integrations/slack.md) and [../api/destinations.md](../api/destinations.md).

## Support tickets

Customer support tickets for the workspace. Full guide: [../api/support.md](../api/support.md) and [admin-portal.md](admin-portal.md#support-tickets).

| Method | Endpoint | Who | Notes |
| --- | --- | --- | --- |
| `POST` | `/v1/support/tickets` | Authenticated user | Open a ticket (`channel: skill` with Bearer token). |
| `GET` | `/v1/support/tickets?scope=mine` | Requester | Own tickets. |
| `GET` | `/v1/support/tickets?scope=workspace&workspace={id}` | Admin/owner | Workspace ticket list. |
| `GET` | `/v1/support/tickets/{id}` | Requester, workspace admin, super-admin | Ticket + thread. |
| `POST` | `/v1/support/tickets/{id}/message` | Requester | Add a follow-up (reopens if resolved). |
| `POST` | `/v1/support/tickets/{id}/reply` | Staff | Send reply on origin channel. |
| `POST` | `/v1/support/tickets/{id}/status` | Staff | e.g. `{ "status": "resolved" }`. |
| `POST` | `/v1/support/tickets/{id}/assign` | Staff | Assign to a workspace member. |
| `POST` | `/v1/support/tickets/{id}/triage` | Staff | Re-run AI triage draft. |
