# Artifact Crew (autonomous agents)

Each artifact can run a **crew** — an autonomous agent with tools to query data, refresh snapshots, write JSON summaries, deliver to destinations, and more. Crews are triggered on a schedule, by metric-alert follow-up (`on_trigger`), from the Telegram bot (`ask_crew`), or manually via the crew API.

> **Different from in-artifact chat:** `sdk.agent` is a visitor-facing widget inside the published page. Crew runs server-side with owner-scoped tools. See [overview.md](overview.md) for visitor chat.

## Refresh → narrate → deliver

A common automation chain for warehouse-backed dashboards:

1. **Refresh (deterministic)** — a `query_snapshot` cron job runs fixed SQL against a workspace connection and writes results into `sdk.json` (or a table/dataset). No LLM; SQL lives in job config. See [../api/jobs.md](../api/jobs.md#querysnapshotconfig).
2. **Narrate (crew)** — a scheduled crew reads the refreshed json, calls `json_set` to store a summary, and uses `connection_query` for small follow-up lookups if needed.
3. **Deliver (crew or job)** — `notify_send` posts the narrative (+ optional snapshot/PDF) to Slack/Telegram/email, or a separate delivery job runs on the same schedule.

Use `query_snapshot` when SQL is stable; use crew `materialize_query` when the agent should decide what to refresh interactively.

## Data tools

### `connection_query` (read)

Query a workspace connection by name. Works for REST (`query = "GET /endpoint"`) **and** SQL warehouses like BigQuery (`query` = SQL string; pass `params.projectId` for BigQuery). Returns rows to the crew context — best for aggregates and small result sets.

A REST connection whose `baseUrl` is this instance's own origin is routed in-process (a Worker cannot fetch its own zone: 522). Runs on the **artifact owner's** per-user credentials when the connection is `per_user`, so unattended crews can query BigQuery the same way the interactive data API does.

### `materialize_query` (write)

Run a connection query and **save** results without loading every row into the conversation. Targets:

| `target.type` | Writes to |
|---------------|-----------|
| `table` | `sdk.table(name)` |
| `dataset` | `sdk.dataset(name)` |
| `json` | `sdk.json` key `name`; optional `path` merges at a field inside the key's object |

```jsonc
{
  "connection": "team_bigquery",
  "query": "SELECT * FROM `project.dataset.table` LIMIT 500",
  "params": { "projectId": "my-gcp-project" },
  "target": { "type": "json", "name": "snapshot", "path": "rows" }
}
```

### `json_set` (write)

Owner-scoped write to the artifact JSON store. Creates or replaces a key; optional `path` sets one field inside the key's object (same merge semantics as materialize json targets). Blocked when a row-level `access_policy` is active (JSON store is owner/editor-only under a policy).

Use for computed summaries, status flags, or narratives the page reads on next load.

## Delivery tools

### `notify_send` (write, always requires approval)

One-shot delivery via the shared destination layer (Slack, email, Discord, webhook). Pass a top-level `message` to send the crew's own narrative text — it is forwarded as the destination's `customMessage` (Slack `mode: "both"` attaches screenshot + link alongside the message).

```jsonc
{
  "destination": "slack",
  "message": "*Daily summary*\nRevenue up 12% vs yesterday.",
  "source": {
    "connection": "acme_snowflake",
    "query": "SELECT SUM(amount) FROM orders WHERE day = CURRENT_DATE",
    "asOf": "2026-06-22"
  },
  "config": {
    "connection": "team",
    "channelId": "C0123456789",
    "mode": "both"
  }
}
```

**Always pass `source`** when delivering data-derived numbers — `{ connection|label, query, asOf, tables?, columns?, filters? }`. A compact attribution footer is appended (`_Source: … · as of …_` plus Tables/Columns/Filters lines or a clipped one-line query) so recipients can trace where the figures came from. State the source + as-of in your narrative too. See [patterns/data-provenance.md](../patterns/data-provenance.md).

### `scheduled_job_create` (write)

Create a recurring delivery job (`POST /v1/jobs` under the hood). Config shapes match [../api/jobs.md](../api/jobs.md).

## Collaboration tools

### `comment_create` (write)

Post a comment on the artifact. Requires comments enabled and owner/editor identity.

### `action_item_create` / `action_item_list` (write / read)

Create or list **action items** — comments assigned to a workspace member or collaborator with an optional due date. The assignee is notified by email and Telegram. See [../sdk/comments.md](../sdk/comments.md#action-items).

## REST API

All routes live under the artifact's data API and are **artifact-owner only** (owner's
`Authorization: Bearer so_…` token or session; others get `403`). Responses use the data
envelope `{ "success": true, "data": … }`. One crew per artifact.

| Method | Path | Notes |
|--------|------|-------|
| GET | `/v1/data/{id}/crew` | `{ crew, grants[] }`; `404` if none defined |
| DELETE | `/v1/data/{id}/crew` | Delete the crew and its grants, triggers, runs and approvals (`404` if none) |
| POST | `/v1/data/{id}/crew/define` | Create or replace the crew (upsert). Body below. Grants are rewritten from `tools` |
| POST | `/v1/data/{id}/crew/run` | `{ "input": "…" }` (optional). Streams **SSE** events: `run_start`, `reasoning`, `tool_call`, `tool_result`, `finish`, `error`, `done`. `429 CONCURRENCY_LIMIT` when too many runs are active |
| GET | `/v1/data/{id}/crew/runs` | Last 20 runs |
| GET | `/v1/data/{id}/crew/runs/{runId}` | `{ run, events[] }` |
| GET | `/v1/data/{id}/crew/runs/{runId}/stream` | Replays a run's stored events as SSE |
| GET / POST | `/v1/data/{id}/crew/triggers` | List / create a trigger |
| PATCH / DELETE | `/v1/data/{id}/crew/triggers/{triggerId}` | Update (`enabled`, `cron`, `eventType`) / delete |
| GET | `/v1/data/{id}/crew/approvals?status=pending` | Pending write-tool approvals |
| POST | `/v1/data/{id}/crew/approvals/{approvalId}/approve` \| `/reject` | Approve (executes the tool) or reject |

```jsonc
// POST /v1/data/{id}/crew/define
{
  "name": "Daily narrator",
  "instructions": "Read json key `snapshot`, write a 3-line summary to `summary`, then notify Slack.",
  "model": "<optional; unsupported values fall back to the default>",
  "maxIterations": 8,                 // clamped to the plan cap
  "runBudgetMicroUsd": 200000,        // optional
  "maxRuntimeMs": 90000,              // optional; scheduled (cron/condition) runs only, max 120000. Manual, event and chat-triggered runs stay at 25000
  "tools": {
    "read":  ["json_get", "table_query", "connection_query"],
    "write": ["json_set", "notify_send"],
    "approval": { "json_set": "never" },   // never | always | whenPublic
    "limits": { "connection_query": { "maxRows": 500, "maxCalls": 5 } }   // maxRows/maxCalls/maxBytes/maxResults
  }
}
```

Tool names — read: `table_query`, `table_schema`, `json_get`, `file_list`, `file_read`,
`web_search`, `connection_query`, `action_item_list`, `workspace_artifacts` (list the workspace's artifacts the owner can open), `workspace_data_read` (read a JSON key or table of another artifact in the same workspace, in-process), `knowledge_search` (cited passages from workspace Knowledge, as the crew owner). Write: `json_set`, `table_insert`,
`table_update`, `comment_create`, `action_item_create`, `email_send`, `materialize_query`,
`scheduled_job_create`, `notify_send`, `pilot_verify`. Unknown names, or a name listed under
the wrong mode, are ignored silently — check `grants` in `GET /crew` after defining.

`email_send` (and every artifact email: scheduled jobs, `sdk.email`) sends one message per recipient with an unsubscribe footer link and RFC 8058 `List-Unsubscribe` / `List-Unsubscribe-Post` headers. A recipient who unsubscribes is stored per artifact (`artifact_email_optouts`), skipped on later sends, and reported back as `skipped_opted_out`; the owner can list them with `GET /v1/data/{id}/email/optouts`. The unsubscribe page is Spanish (es-AR) for Spanish workspaces, English otherwise, and can opt back in.

Concurrency: an owner runs one crew at a time by default (`plan_crew_limits.max_concurrent_runs`, or 1 without a row). An **event** trigger that fires while the owner is busy is not dropped: it is queued (`crew_runs.status = 'queued'`, max 20 per owner, 24 h) and starts, oldest first, in the next hourly tick (at its start, and again after its due triggers if budget remains), so worst-case latency is about an hour. A run abandoned in `running` (worker killed) is reaped after 5 minutes, at the next dispatch or tick, and frees the slot; an event run killed before its first tool call is re-queued once. Cron triggers that find the owner busy retry hourly for 6 h.

Triggers (`POST /crew/triggers`):

```jsonc
{ "kind": "cron", "cron": "0 9 * * 1-5" }                     // hourly-granular worker cron
{ "kind": "event", "eventType": "table.row.inserted" }          // only supported event
{ "kind": "condition", "condition": {                           // checked hourly
    "predicate": { "table": "orders", "where": { "status": "late" }, "op": "gt", "value": 5 },
    "cooldownSeconds": 86400 } }
```

There is no crew catalog/template endpoint; define each crew per artifact.

## Permissions & limits

- Crew tools run with **owner** identity (`principal.ownerId`) for data writes and warehouse queries.
- Write tools may require owner approval when the artifact is public (`whenPublic`) or always (`notify_send`).
- Feature flag `ai.crew` must be enabled for the workspace. See [../api/features.md](../api/features.md).
- Per-user connectors work for crew warehouse queries; scheduled `materialize`/`query_snapshot` jobs still need shared connectors or owner-linked credentials.

## Related

- [../api/jobs.md](../api/jobs.md) — `query_snapshot`, event triggers, delivery configs
- [../api/destinations.md](../api/destinations.md) — destination layer shared by jobs and crew
- [../integrations/slack.md](../integrations/slack.md) — Slack delivery from `notify_send`
- [telegram.md](telegram.md) — `ask_crew` from Telegram
